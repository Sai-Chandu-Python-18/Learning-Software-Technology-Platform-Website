import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Play, Star, Users, BookOpen, Award, TrendingUp, Code, Database, Cloud, Smartphone } from 'lucide-react';

const HomePage = () => {
  const features = [
    {
      icon: <BookOpen className="h-8 w-8" />,
      title: "Expert-Led Courses",
      description: "Learn from industry professionals with real-world experience"
    },
    {
      icon: <Users className="h-8 w-8" />,
      title: "Interactive Learning",
      description: "Hands-on projects and peer collaboration for better retention"
    },
    {
      icon: <Award className="h-8 w-8" />,
      title: "Industry Certificates",
      description: "Earn recognized certifications to advance your career"
    },
    {
      icon: <TrendingUp className="h-8 w-8" />,
      title: "Progress Tracking",
      description: "Monitor your learning journey with detailed analytics"
    }
  ];

  const learningPaths = [
    {
      id: 1,
      title: "Frontend Development",
      description: "Master React, TypeScript, and modern frontend tools",
      icon: <Code className="h-12 w-12" />,
      courses: 12,
      duration: "6 months",
      level: "Beginner to Advanced",
      color: "from-blue-500 to-cyan-500"
    },
    {
      id: 2,
      title: "Backend Engineering",
      description: "Build scalable APIs with Node.js, Python, and databases",
      icon: <Database className="h-12 w-12" />,
      courses: 15,
      duration: "8 months",
      level: "Intermediate",
      color: "from-emerald-500 to-teal-500"
    },
    {
      id: 3,
      title: "Cloud Computing",
      description: "Deploy and manage applications on AWS, Azure, and GCP",
      icon: <Cloud className="h-12 w-12" />,
      courses: 10,
      duration: "4 months",
      level: "Intermediate to Advanced",
      color: "from-purple-500 to-pink-500"
    },
    {
      id: 4,
      title: "Mobile Development",
      description: "Create cross-platform apps with React Native and Flutter",
      icon: <Smartphone className="h-12 w-12" />,
      courses: 8,
      duration: "5 months",
      level: "Beginner to Intermediate",
      color: "from-orange-500 to-red-500"
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-900 via-blue-800 to-purple-800 overflow-hidden">
        <div className="absolute inset-0 bg-black opacity-20"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="text-white">
              <h1 className="text-5xl lg:text-6xl font-bold leading-tight mb-6">
                Master the Future of
                <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
                  {" "}Technology
                </span>
              </h1>
              <p className="text-xl text-blue-100 mb-8 leading-relaxed">
                Join thousands of developers learning cutting-edge technologies through hands-on projects, 
                expert mentorship, and industry-recognized certifications.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  to="/courses"
                  className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-cyan-500 to-blue-500 text-white font-semibold rounded-lg hover:shadow-xl transform hover:scale-105 transition-all"
                >
                  Start Learning
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
                <button className="inline-flex items-center px-8 py-4 border-2 border-white text-white font-semibold rounded-lg hover:bg-white hover:text-blue-900 transition-all">
                  <Play className="mr-2 h-5 w-5" />
                  Watch Demo
                </button>
              </div>
              <div className="flex items-center mt-8 text-blue-100">
                <div className="flex items-center mr-6">
                  <Star className="h-5 w-5 text-yellow-400 mr-1" />
                  <span className="font-semibold">4.9/5</span>
                  <span className="ml-1">from 10k+ reviews</span>
                </div>
                <div className="flex items-center">
                  <Users className="h-5 w-5 mr-1" />
                  <span>50k+ active learners</span>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gradient-to-br from-cyan-500/20 to-blue-500/20 rounded-lg p-4 border border-cyan-500/30">
                    <Code className="h-8 w-8 text-cyan-400 mb-2" />
                    <h3 className="text-white font-semibold">Frontend</h3>
                    <p className="text-cyan-100 text-sm">React, Vue, Angular</p>
                  </div>
                  <div className="bg-gradient-to-br from-emerald-500/20 to-teal-500/20 rounded-lg p-4 border border-emerald-500/30">
                    <Database className="h-8 w-8 text-emerald-400 mb-2" />
                    <h3 className="text-white font-semibold">Backend</h3>
                    <p className="text-emerald-100 text-sm">Node.js, Python, Go</p>
                  </div>
                  <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-lg p-4 border border-purple-500/30">
                    <Cloud className="h-8 w-8 text-purple-400 mb-2" />
                    <h3 className="text-white font-semibold">Cloud</h3>
                    <p className="text-purple-100 text-sm">AWS, Azure, GCP</p>
                  </div>
                  <div className="bg-gradient-to-br from-orange-500/20 to-red-500/20 rounded-lg p-4 border border-orange-500/30">
                    <Smartphone className="h-8 w-8 text-orange-400 mb-2" />
                    <h3 className="text-white font-semibold">Mobile</h3>
                    <p className="text-orange-100 text-sm">React Native, Flutter</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Why Choose TechLearn?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our platform combines the best of online learning with practical, real-world experience
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="text-center group">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 text-white rounded-xl mb-6 group-hover:scale-110 transition-transform">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Learning Paths Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Choose Your Learning Path
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Structured learning journeys designed to take you from beginner to professional
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {learningPaths.map((path) => (
              <div key={path.id} className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all group cursor-pointer">
                <div className={`inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r ${path.color} text-white rounded-xl mb-6 group-hover:scale-110 transition-transform`}>
                  {path.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{path.title}</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">{path.description}</p>
                <div className="space-y-2 text-sm text-gray-500 mb-6">
                  <div className="flex justify-between">
                    <span>Courses:</span>
                    <span className="font-semibold">{path.courses}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Duration:</span>
                    <span className="font-semibold">{path.duration}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Level:</span>
                    <span className="font-semibold">{path.level}</span>
                  </div>
                </div>
                <Link
                  to="/courses"
                  className="block w-full text-center px-4 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-colors"
                >
                  Explore Path
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-900 to-purple-900">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Transform Your Career?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Join our community of learners and start building your future in tech today
          </p>
          <Link
            to="/courses"
            className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-cyan-500 to-blue-500 text-white font-semibold rounded-lg hover:shadow-xl transform hover:scale-105 transition-all"
          >
            Get Started Now
            <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;