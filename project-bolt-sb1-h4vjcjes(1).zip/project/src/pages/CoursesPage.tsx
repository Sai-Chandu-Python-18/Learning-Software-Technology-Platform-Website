import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Filter, Clock, Users, Star, Play, BookOpen } from 'lucide-react';

const CoursesPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedLevel, setSelectedLevel] = useState('all');

  const categories = [
    { id: 'all', name: 'All Categories' },
    { id: 'frontend', name: 'Frontend Development' },
    { id: 'backend', name: 'Backend Development' },
    { id: 'mobile', name: 'Mobile Development' },
    { id: 'cloud', name: 'Cloud Computing' },
    { id: 'ai', name: 'AI & Machine Learning' },
    { id: 'devops', name: 'DevOps' }
  ];

  const levels = [
    { id: 'all', name: 'All Levels' },
    { id: 'beginner', name: 'Beginner' },
    { id: 'intermediate', name: 'Intermediate' },
    { id: 'advanced', name: 'Advanced' }
  ];

  const courses = [
    {
      id: 1,
      title: "React Mastery: Modern Frontend Development",
      instructor: "Sarah Johnson",
      category: "frontend",
      level: "intermediate",
      duration: "12 hours",
      students: 2840,
      rating: 4.9,
      price: 89,
      thumbnail: "https://images.pexels.com/photos/270348/pexels-photo-270348.jpeg",
      description: "Master React with hooks, context, and modern development patterns",
      lessons: 45,
      projects: 8
    },
    {
      id: 2,
      title: "Node.js & Express: Complete Backend Guide",
      instructor: "Michael Chen",
      category: "backend",
      level: "beginner",
      duration: "16 hours",
      students: 1920,
      rating: 4.8,
      price: 79,
      thumbnail: "https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg",
      description: "Build robust APIs and web applications with Node.js and Express",
      lessons: 52,
      projects: 6
    },
    {
      id: 3,
      title: "AWS Cloud Practitioner Certification",
      instructor: "David Rodriguez",
      category: "cloud",
      level: "beginner",
      duration: "20 hours",
      students: 3250,
      rating: 4.7,
      price: 129,
      thumbnail: "https://images.pexels.com/photos/1181298/pexels-photo-1181298.jpeg",
      description: "Get certified as an AWS Cloud Practitioner with hands-on labs",
      lessons: 68,
      projects: 12
    },
    {
      id: 4,
      title: "Flutter Mobile App Development",
      instructor: "Emily Wang",
      category: "mobile",
      level: "intermediate",
      duration: "18 hours",
      students: 1560,
      rating: 4.8,
      price: 99,
      thumbnail: "https://images.pexels.com/photos/607812/pexels-photo-607812.jpeg",
      description: "Create beautiful cross-platform mobile apps with Flutter",
      lessons: 42,
      projects: 5
    },
    {
      id: 5,
      title: "Python Machine Learning Fundamentals",
      instructor: "Dr. Alex Thompson",
      category: "ai",
      level: "intermediate",
      duration: "24 hours",
      students: 2100,
      rating: 4.9,
      price: 149,
      thumbnail: "https://images.pexels.com/photos/574077/pexels-photo-574077.jpeg",
      description: "Learn machine learning with Python, scikit-learn, and TensorFlow",
      lessons: 56,
      projects: 10
    },
    {
      id: 6,
      title: "Docker & Kubernetes for DevOps",
      instructor: "James Wilson",
      category: "devops",
      level: "advanced",
      duration: "22 hours",
      students: 1280,
      rating: 4.8,
      price: 139,
      thumbnail: "https://images.pexels.com/photos/1181472/pexels-photo-1181472.jpeg",
      description: "Master containerization and orchestration for modern DevOps",
      lessons: 48,
      projects: 8
    }
  ];

  const filteredCourses = courses.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         course.instructor.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || course.category === selectedCategory;
    const matchesLevel = selectedLevel === 'all' || course.level === selectedLevel;
    
    return matchesSearch && matchesCategory && matchesLevel;
  });

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Explore Courses</h1>
          <p className="text-xl text-gray-600">Discover courses that will accelerate your tech career</p>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="grid md:grid-cols-3 gap-4">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                placeholder="Search courses..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            {/* Category Filter */}
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {categories.map(category => (
                <option key={category.id} value={category.id}>{category.name}</option>
              ))}
            </select>

            {/* Level Filter */}
            <select
              value={selectedLevel}
              onChange={(e) => setSelectedLevel(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {levels.map(level => (
                <option key={level.id} value={level.id}>{level.name}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-6">
          <p className="text-gray-600">
            Showing {filteredCourses.length} of {courses.length} courses
          </p>
        </div>

        {/* Course Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredCourses.map((course) => (
            <div key={course.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow group">
              <div className="relative">
                <img 
                  src={course.thumbnail}
                  alt={course.title}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform"
                />
                <div className="absolute inset-0 bg-black bg-opacity-20 group-hover:bg-opacity-30 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
                  <Play className="h-12 w-12 text-white" />
                </div>
                <div className="absolute top-4 right-4">
                  <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                    course.level === 'beginner' ? 'bg-green-100 text-green-800' :
                    course.level === 'intermediate' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {course.level.charAt(0).toUpperCase() + course.level.slice(1)}
                  </span>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                  {course.title}
                </h3>
                <p className="text-gray-600 mb-3 line-clamp-2">{course.description}</p>
                <p className="text-sm text-gray-500 mb-4">by {course.instructor}</p>
                
                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    <span>{course.duration}</span>
                  </div>
                  <div className="flex items-center">
                    <BookOpen className="h-4 w-4 mr-1" />
                    <span>{course.lessons} lessons</span>
                  </div>
                  <div className="flex items-center">
                    <Users className="h-4 w-4 mr-1" />
                    <span>{course.students.toLocaleString()}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-400 mr-1" />
                    <span className="font-semibold">{course.rating}</span>
                  </div>
                  <div className="text-2xl font-bold text-blue-600">
                    ${course.price}
                  </div>
                </div>

                <Link
                  to={`/course/${course.id}`}
                  className="block w-full text-center px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:shadow-lg transition-all"
                >
                  View Course
                </Link>
              </div>
            </div>
          ))}
        </div>

        {filteredCourses.length === 0 && (
          <div className="text-center py-12">
            <div className="text-gray-400 mb-4">
              <BookOpen className="h-16 w-16 mx-auto" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No courses found</h3>
            <p className="text-gray-600">Try adjusting your search criteria</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CoursesPage;