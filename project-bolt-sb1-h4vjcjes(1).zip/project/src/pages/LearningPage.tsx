import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  Play, Pause, SkipForward, SkipBack, Volume2, Settings, 
  Maximize, BookOpen, CheckCircle, Lock, ChevronLeft, 
  ChevronRight, MessageCircle, Download, Star
} from 'lucide-react';

const LearningPage = () => {
  const { courseId, lessonId } = useParams();
  const [isPlaying, setIsPlaying] = useState(false);
  const [showNotes, setShowNotes] = useState(false);
  const [currentSpeed, setCurrentSpeed] = useState(1);

  // Mock lesson data
  const course = {
    id: 1,
    title: "React Mastery: Modern Frontend Development",
    totalLessons: 45
  };

  const currentLesson = {
    id: 1,
    title: "Custom Hooks Deep Dive",
    duration: "18:24",
    description: "Learn how to create powerful custom hooks that encapsulate complex logic and make your React components cleaner and more reusable.",
    videoUrl: "https://example.com/video",
    transcript: `In this lesson, we'll explore the power of custom hooks in React. Custom hooks allow us to extract component logic into reusable functions.

Let's start by understanding what custom hooks are and why they're so powerful for React development.

A custom hook is simply a JavaScript function whose name starts with "use" and that may call other hooks. This simple convention allows you to extract component logic into reusable functions.`,
    
    resources: [
      { name: "Custom Hooks Cheat Sheet", type: "pdf", size: "2.3 MB" },
      { name: "Code Examples", type: "zip", size: "1.8 MB" },
      { name: "Homework Assignment", type: "doc", size: "156 KB" }
    ]
  };

  const lessons = [
    { id: 1, title: "Custom Hooks Deep Dive", duration: "18:24", completed: false, current: true },
    { id: 2, title: "useReducer for Complex State", duration: "22:15", completed: false, current: false },
    { id: 3, title: "useContext Best Practices", duration: "16:42", completed: false, current: false },
    { id: 4, title: "useCallback and Performance", duration: "20:30", completed: false, current: false },
    { id: 5, title: "useMemo Optimization", duration: "15:18", completed: false, current: false }
  ];

  const notes = [
    {
      timestamp: "02:15",
      text: "Custom hooks must start with 'use' prefix",
      author: "You"
    },
    {
      timestamp: "05:42",
      text: "Great explanation of the separation of concerns principle",
      author: "Sarah M."
    },
    {
      timestamp: "12:30",
      text: "Remember to handle cleanup in custom hooks",
      author: "You"
    }
  ];

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  const changeSpeed = () => {
    const speeds = [0.5, 0.75, 1, 1.25, 1.5, 2];
    const currentIndex = speeds.indexOf(currentSpeed);
    const nextIndex = (currentIndex + 1) % speeds.length;
    setCurrentSpeed(speeds[nextIndex]);
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <div className="flex">
        {/* Main Content */}
        <div className="flex-1">
          {/* Header */}
          <div className="bg-gray-800 px-6 py-4 flex items-center justify-between border-b border-gray-700">
            <div className="flex items-center">
              <Link 
                to={`/course/${courseId}`}
                className="flex items-center text-gray-300 hover:text-white transition-colors mr-4"
              >
                <ChevronLeft className="h-5 w-5 mr-1" />
                Back to Course
              </Link>
              <div>
                <h1 className="text-lg font-semibold">{course.title}</h1>
                <p className="text-sm text-gray-400">
                  Lesson {lessonId} of {course.totalLessons}: {currentLesson.title}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button className="text-gray-300 hover:text-white transition-colors">
                <Settings className="h-5 w-5" />
              </button>
            </div>
          </div>

          {/* Video Player */}
          <div className="relative bg-black aspect-video">
            <div className="absolute inset-0 flex items-center justify-center bg-gray-800">
              <div className="text-center">
                <div className="w-20 h-20 bg-gray-700 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <Play className="h-8 w-8 text-white ml-1" />
                </div>
                <p className="text-gray-300">Video Player Placeholder</p>
                <p className="text-sm text-gray-400 mt-2">{currentLesson.duration}</p>
              </div>
            </div>

            {/* Video Controls */}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <button
                    onClick={togglePlay}
                    className="bg-white bg-opacity-20 hover:bg-opacity-30 rounded-full p-2 transition-all"
                  >
                    {isPlaying ? (
                      <Pause className="h-6 w-6" />
                    ) : (
                      <Play className="h-6 w-6 ml-1" />
                    )}
                  </button>
                  <button className="text-white hover:text-gray-300 transition-colors">
                    <SkipBack className="h-5 w-5" />
                  </button>
                  <button className="text-white hover:text-gray-300 transition-colors">
                    <SkipForward className="h-5 w-5" />
                  </button>
                  <div className="flex items-center space-x-2">
                    <Volume2 className="h-5 w-5" />
                    <div className="w-20 h-1 bg-white bg-opacity-30 rounded-full">
                      <div className="w-3/4 h-full bg-white rounded-full"></div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <button
                    onClick={changeSpeed}
                    className="text-sm bg-white bg-opacity-20 hover:bg-opacity-30 px-2 py-1 rounded transition-all"
                  >
                    {currentSpeed}x
                  </button>
                  <button className="text-white hover:text-gray-300 transition-colors">
                    <Maximize className="h-5 w-5" />
                  </button>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="mt-4">
                <div className="w-full h-1 bg-white bg-opacity-30 rounded-full">
                  <div className="w-1/3 h-full bg-blue-500 rounded-full"></div>
                </div>
                <div className="flex justify-between text-xs text-gray-300 mt-1">
                  <span>06:08</span>
                  <span>{currentLesson.duration}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Lesson Content */}
          <div className="p-6 bg-gray-800">
            <div className="max-w-4xl">
              <h2 className="text-2xl font-bold mb-4">{currentLesson.title}</h2>
              <p className="text-gray-300 leading-relaxed mb-6">{currentLesson.description}</p>

              {/* Tabs */}
              <div className="border-b border-gray-700 mb-6">
                <nav className="-mb-px flex space-x-8">
                  <button 
                    className={`py-2 px-1 border-b-2 font-medium text-sm ${
                      !showNotes 
                        ? 'border-blue-500 text-blue-400' 
                        : 'border-transparent text-gray-400 hover:text-gray-300'
                    }`}
                    onClick={() => setShowNotes(false)}
                  >
                    Transcript
                  </button>
                  <button 
                    className={`py-2 px-1 border-b-2 font-medium text-sm ${
                      showNotes 
                        ? 'border-blue-500 text-blue-400' 
                        : 'border-transparent text-gray-400 hover:text-gray-300'
                    }`}
                    onClick={() => setShowNotes(true)}
                  >
                    Notes ({notes.length})
                  </button>
                </nav>
              </div>

              {/* Tab Content */}
              {!showNotes ? (
                <div className="prose prose-invert max-w-none">
                  {currentLesson.transcript.split('\n\n').map((paragraph, index) => (
                    <p key={index} className="text-gray-300 leading-relaxed mb-4">
                      {paragraph}
                    </p>
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  {notes.map((note, index) => (
                    <div key={index} className="bg-gray-700 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-blue-400 text-sm font-medium">{note.timestamp}</span>
                        <span className="text-gray-400 text-sm">{note.author}</span>
                      </div>
                      <p className="text-gray-300">{note.text}</p>
                    </div>
                  ))}
                  <div className="mt-6">
                    <textarea
                      placeholder="Add a note at current timestamp..."
                      className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      rows={3}
                    />
                    <button className="mt-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                      Add Note
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="w-80 bg-gray-800 border-l border-gray-700">
          {/* Course Progress */}
          <div className="p-6 border-b border-gray-700">
            <h3 className="text-lg font-semibold mb-4">Course Progress</h3>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-400">1 of {course.totalLessons} lessons</span>
              <span className="text-sm text-gray-400">2%</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div className="bg-blue-500 h-2 rounded-full" style={{ width: '2%' }}></div>
            </div>
          </div>

          {/* Lesson List */}
          <div className="p-6 border-b border-gray-700">
            <h3 className="text-lg font-semibold mb-4">Lessons</h3>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {lessons.map((lesson) => (
                <Link
                  key={lesson.id}
                  to={`/learn/${courseId}/${lesson.id}`}
                  className={`flex items-center p-3 rounded-lg transition-colors ${
                    lesson.current 
                      ? 'bg-blue-600 text-white' 
                      : lesson.completed
                      ? 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                      : 'bg-gray-700 text-gray-400 hover:bg-gray-600'
                  }`}
                >
                  <div className="mr-3">
                    {lesson.completed ? (
                      <CheckCircle className="h-5 w-5 text-green-400" />
                    ) : lesson.current ? (
                      <Play className="h-5 w-5" />
                    ) : (
                      <Lock className="h-5 w-5" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{lesson.title}</p>
                    <p className="text-sm opacity-75">{lesson.duration}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>

          {/* Resources */}
          <div className="p-6">
            <h3 className="text-lg font-semibold mb-4">Resources</h3>
            <div className="space-y-3">
              {currentLesson.resources.map((resource, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                  <div className="flex items-center">
                    <Download className="h-4 w-4 text-gray-400 mr-3" />
                    <div>
                      <p className="text-sm font-medium">{resource.name}</p>
                      <p className="text-xs text-gray-400">{resource.size}</p>
                    </div>
                  </div>
                  <button className="text-blue-400 hover:text-blue-300 transition-colors">
                    <Download className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="fixed bottom-6 right-6 flex space-x-4">
        <button className="bg-gray-700 hover:bg-gray-600 p-3 rounded-full transition-colors">
          <ChevronLeft className="h-6 w-6" />
        </button>
        <button className="bg-blue-600 hover:bg-blue-700 p-3 rounded-full transition-colors">
          <ChevronRight className="h-6 w-6" />
        </button>
      </div>
    </div>
  );
};

export default LearningPage;