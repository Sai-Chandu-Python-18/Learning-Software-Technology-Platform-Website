import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Clock, Award, TrendingUp, Play, MoreHorizontal as MoreHorizon, Target, Calendar, Star, ChevronRight } from 'lucide-react';

const DashboardPage = () => {
  const stats = [
    {
      label: "Courses Enrolled",
      value: "8",
      icon: <BookOpen className="h-6 w-6" />,
      color: "from-blue-500 to-blue-600"
    },
    {
      label: "Hours Learned",
      value: "124",
      icon: <Clock className="h-6 w-6" />,
      color: "from-emerald-500 to-emerald-600"
    },
    {
      label: "Certificates",
      value: "3",
      icon: <Award className="h-6 w-6" />,
      color: "from-purple-500 to-purple-600"
    },
    {
      label: "Streak",
      value: "12 days",
      icon: <TrendingUp className="h-6 w-6" />,
      color: "from-orange-500 to-orange-600"
    }
  ];

  const enrolledCourses = [
    {
      id: 1,
      title: "React Mastery: Modern Frontend Development",
      instructor: "Sarah Johnson",
      progress: 75,
      nextLesson: "Custom Hook Patterns",
      thumbnail: "https://images.pexels.com/photos/270348/pexels-photo-270348.jpeg",
      lastAccessed: "2 hours ago"
    },
    {
      id: 2,
      title: "Node.js & Express: Complete Backend Guide",
      instructor: "Michael Chen",
      progress: 45,
      nextLesson: "Authentication with JWT",
      thumbnail: "https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg",
      lastAccessed: "1 day ago"
    },
    {
      id: 3,
      title: "AWS Cloud Practitioner Certification",
      instructor: "David Rodriguez",
      progress: 60,
      nextLesson: "EC2 Instance Types",
      thumbnail: "https://images.pexels.com/photos/1181298/pexels-photo-1181298.jpeg",
      lastAccessed: "3 days ago"
    }
  ];

  const achievements = [
    {
      title: "First Course Completed",
      description: "Completed your first course",
      icon: "🎯",
      date: "2 weeks ago"
    },
    {
      title: "Week Warrior",
      description: "Learned for 7 consecutive days",
      icon: "🔥",
      date: "5 days ago"
    },
    {
      title: "Frontend Master",
      description: "Completed 3 frontend courses",
      icon: "⚡",
      date: "1 week ago"
    }
  ];

  const upcomingDeadlines = [
    {
      course: "React Mastery",
      task: "Final Project Submission",
      dueDate: "Tomorrow",
      urgent: true
    },
    {
      course: "AWS Certification",
      task: "Practice Exam",
      dueDate: "3 days",
      urgent: false
    },
    {
      course: "Node.js Backend",
      task: "API Development Assignment",
      dueDate: "1 week",
      urgent: false
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome back, Alex!</h1>
          <p className="text-lg text-gray-600">Continue your learning journey</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg p-6">
              <div className="flex items-center">
                <div className={`p-3 rounded-lg bg-gradient-to-r ${stat.color} text-white mr-4`}>
                  {stat.icon}
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  <p className="text-sm text-gray-600">{stat.label}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Continue Learning */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-900">Continue Learning</h2>
                <Link to="/courses" className="text-blue-600 hover:text-blue-700 font-medium">
                  View All
                </Link>
              </div>
              
              <div className="space-y-4">
                {enrolledCourses.map((course) => (
                  <div key={course.id} className="flex items-center p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
                    <img 
                      src={course.thumbnail}
                      alt={course.title}
                      className="w-16 h-16 rounded-lg object-cover mr-4"
                    />
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900 mb-1">{course.title}</h3>
                      <p className="text-sm text-gray-600 mb-2">by {course.instructor}</p>
                      
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex-1 mr-4">
                          <div className="flex items-center justify-between text-sm text-gray-600 mb-1">
                            <span>Progress</span>
                            <span>{course.progress}%</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full"
                              style={{ width: `${course.progress}%` }}
                            ></div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <p className="text-sm text-gray-500">
                          Next: {course.nextLesson}
                        </p>
                        <p className="text-xs text-gray-400">{course.lastAccessed}</p>
                      </div>
                    </div>
                    
                    <Link
                      to={`/learn/${course.id}/1`}
                      className="ml-4 flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      <Play className="h-4 w-4 mr-2" />
                      Continue
                    </Link>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent Achievements */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-6">Recent Achievements</h2>
              <div className="space-y-4">
                {achievements.map((achievement, index) => (
                  <div key={index} className="flex items-center p-4 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg border border-yellow-200">
                    <div className="text-2xl mr-4">{achievement.icon}</div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{achievement.title}</h3>
                      <p className="text-sm text-gray-600">{achievement.description}</p>
                    </div>
                    <span className="text-xs text-gray-500">{achievement.date}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* Learning Goals */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-4">This Week's Goal</h3>
              <div className="text-center">
                <div className="relative w-24 h-24 mx-auto mb-4">
                  <svg className="w-24 h-24 transform -rotate-90">
                    <circle
                      cx="48"
                      cy="48"
                      r="40"
                      stroke="currentColor"
                      strokeWidth="8"
                      fill="transparent"
                      className="text-gray-200"
                    />
                    <circle
                      cx="48"
                      cy="48"
                      r="40"
                      stroke="currentColor"
                      strokeWidth="8"
                      fill="transparent"
                      strokeDasharray={`${2 * Math.PI * 40}`}
                      strokeDashoffset={`${2 * Math.PI * 40 * (1 - 0.7)}`}
                      className="text-blue-500"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-xl font-bold text-gray-900">70%</span>
                  </div>
                </div>
                <p className="text-sm text-gray-600 mb-2">7 of 10 hours completed</p>
                <div className="flex items-center justify-center text-sm text-blue-600">
                  <Target className="h-4 w-4 mr-1" />
                  <span>Keep it up!</span>
                </div>
              </div>
            </div>

            {/* Upcoming Deadlines */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Upcoming Deadlines</h3>
              <div className="space-y-3">
                {upcomingDeadlines.map((deadline, index) => (
                  <div key={index} className={`p-3 rounded-lg ${deadline.urgent ? 'bg-red-50 border border-red-200' : 'bg-gray-50'}`}>
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="font-medium text-gray-900 text-sm">{deadline.course}</h4>
                      <span className={`text-xs px-2 py-1 rounded-full ${deadline.urgent ? 'bg-red-100 text-red-800' : 'bg-gray-200 text-gray-600'}`}>
                        {deadline.dueDate}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600">{deadline.task}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <Link
                  to="/courses"
                  className="flex items-center justify-between p-3 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg hover:shadow-md transition-shadow"
                >
                  <div className="flex items-center">
                    <BookOpen className="h-5 w-5 text-blue-600 mr-3" />
                    <span className="font-medium text-gray-900">Browse Courses</span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-gray-400" />
                </Link>
                
                <Link
                  to="/profile"
                  className="flex items-center justify-between p-3 bg-gradient-to-r from-emerald-50 to-teal-50 rounded-lg hover:shadow-md transition-shadow"
                >
                  <div className="flex items-center">
                    <Award className="h-5 w-5 text-emerald-600 mr-3" />
                    <span className="font-medium text-gray-900">View Certificates</span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-gray-400" />
                </Link>
                
                <button className="w-full flex items-center justify-between p-3 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg hover:shadow-md transition-shadow">
                  <div className="flex items-center">
                    <Calendar className="h-5 w-5 text-purple-600 mr-3" />
                    <span className="font-medium text-gray-900">Schedule Study Time</span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-gray-400" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;