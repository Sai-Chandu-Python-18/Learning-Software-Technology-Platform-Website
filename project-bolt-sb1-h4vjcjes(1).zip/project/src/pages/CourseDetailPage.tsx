import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  Play, Clock, Users, Star, BookOpen, Award, CheckCircle, 
  ChevronDown, ChevronUp, Download, Share2, Heart 
} from 'lucide-react';

const CourseDetailPage = () => {
  const { id } = useParams();
  const [expandedModule, setExpandedModule] = useState<number | null>(0);

  // Mock course data - in real app, this would come from API
  const course = {
    id: 1,
    title: "React Mastery: Modern Frontend Development",
    subtitle: "Build production-ready React applications with hooks, context, and modern development patterns",
    instructor: {
      name: "Sarah Johnson",
      title: "Senior Frontend Engineer at Google",
      avatar: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg",
      rating: 4.9,
      students: 12500,
      courses: 8
    },
    rating: 4.9,
    reviews: 1247,
    students: 2840,
    duration: "12 hours",
    lessons: 45,
    level: "Intermediate",
    price: 89,
    originalPrice: 149,
    thumbnail: "https://images.pexels.com/photos/270348/pexels-photo-270348.jpeg",
    preview: "https://example.com/preview-video",
    description: `This comprehensive React course takes you from intermediate concepts to advanced patterns used in production applications. You'll learn modern React development with hooks, context API, performance optimization, testing, and deployment strategies.

    Perfect for developers who have basic React knowledge and want to master advanced concepts used by top tech companies.`,
    
    whatYoullLearn: [
      "Build complex React applications with modern hooks",
      "Master state management with Context API and useReducer",
      "Implement advanced patterns like compound components",
      "Optimize performance with React.memo, useMemo, and useCallback",
      "Test React components with Jest and React Testing Library",
      "Deploy applications to production with CI/CD pipelines",
      "Handle forms and validation efficiently",
      "Work with APIs and manage loading states"
    ],

    requirements: [
      "Basic knowledge of JavaScript (ES6+)",
      "Familiarity with React fundamentals",
      "Understanding of HTML and CSS",
      "Node.js installed on your computer"
    ],

    modules: [
      {
        title: "Advanced React Hooks",
        lessons: 8,
        duration: "2h 30m",
        lessons_detail: [
          { title: "Custom Hooks Deep Dive", duration: "18m", preview: true },
          { title: "useReducer for Complex State", duration: "22m", preview: false },
          { title: "useContext Best Practices", duration: "16m", preview: false },
          { title: "useCallback and Performance", duration: "20m", preview: false },
          { title: "useMemo Optimization", duration: "15m", preview: false },
          { title: "useRef Beyond DOM Access", duration: "19m", preview: false },
          { title: "useLayoutEffect vs useEffect", duration: "12m", preview: false },
          { title: "Custom Hook Patterns", duration: "28m", preview: false }
        ]
      },
      {
        title: "State Management Patterns",
        lessons: 6,
        duration: "1h 45m",
        lessons_detail: [
          { title: "Context API Architecture", duration: "25m", preview: false },
          { title: "Reducer Patterns", duration: "20m", preview: false },
          { title: "State Normalization", duration: "18m", preview: false },
          { title: "Optimistic Updates", duration: "22m", preview: false },
          { title: "Caching Strategies", duration: "15m", preview: false },
          { title: "Global vs Local State", duration: "15m", preview: false }
        ]
      },
      {
        title: "Performance Optimization",
        lessons: 7,
        duration: "2h 15m",
        lessons_detail: [
          { title: "React.memo and Memoization", duration: "20m", preview: false },
          { title: "Code Splitting with Lazy Loading", duration: "25m", preview: false },
          { title: "Bundle Analysis", duration: "15m", preview: false },
          { title: "Virtual Scrolling", duration: "30m", preview: false },
          { title: "Performance Profiling", duration: "18m", preview: false },
          { title: "Memory Leak Prevention", duration: "22m", preview: false },
          { title: "Optimization Best Practices", duration: "25m", preview: false }
        ]
      }
    ]
  };

  const toggleModule = (moduleIndex: number) => {
    setExpandedModule(expandedModule === moduleIndex ? null : moduleIndex);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Course Header */}
            <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
              <div className="flex items-start justify-between mb-6">
                <div className="flex-1">
                  <h1 className="text-3xl font-bold text-gray-900 mb-3">{course.title}</h1>
                  <p className="text-lg text-gray-600 leading-relaxed mb-4">{course.subtitle}</p>
                  
                  <div className="flex items-center space-x-6 text-sm text-gray-500 mb-6">
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-400 mr-1" />
                      <span className="font-semibold mr-1">{course.rating}</span>
                      <span>({course.reviews.toLocaleString()} reviews)</span>
                    </div>
                    <div className="flex items-center">
                      <Users className="h-4 w-4 mr-1" />
                      <span>{course.students.toLocaleString()} students</span>
                    </div>
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      <span>{course.duration}</span>
                    </div>
                    <div className="flex items-center">
                      <BookOpen className="h-4 w-4 mr-1" />
                      <span>{course.lessons} lessons</span>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4">
                    <button className="flex items-center px-4 py-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                      <Share2 className="h-4 w-4 mr-2" />
                      Share
                    </button>
                    <button className="flex items-center px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                      <Heart className="h-4 w-4 mr-2" />
                      Wishlist
                    </button>
                  </div>
                </div>
              </div>

              {/* Instructor Info */}
              <div className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
                <img 
                  src={course.instructor.avatar}
                  alt={course.instructor.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <h3 className="font-semibold text-gray-900">{course.instructor.name}</h3>
                  <p className="text-sm text-gray-600">{course.instructor.title}</p>
                  <div className="flex items-center text-xs text-gray-500 mt-1">
                    <Star className="h-3 w-3 text-yellow-400 mr-1" />
                    <span className="mr-3">{course.instructor.rating} rating</span>
                    <span className="mr-3">{course.instructor.students.toLocaleString()} students</span>
                    <span>{course.instructor.courses} courses</span>
                  </div>
                </div>
              </div>
            </div>

            {/* What You'll Learn */}
            <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">What you'll learn</h2>
              <div className="grid md:grid-cols-2 gap-4">
                {course.whatYoullLearn.map((item, index) => (
                  <div key={index} className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">{item}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Course Content */}
            <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Course content</h2>
              <div className="mb-6">
                <p className="text-gray-600">
                  {course.modules.length} modules • {course.lessons} lessons • {course.duration} total length
                </p>
              </div>

              <div className="space-y-4">
                {course.modules.map((module, moduleIndex) => (
                  <div key={moduleIndex} className="border border-gray-200 rounded-lg">
                    <button
                      onClick={() => toggleModule(moduleIndex)}
                      className="w-full flex items-center justify-between p-4 text-left hover:bg-gray-50 transition-colors"
                    >
                      <div>
                        <h3 className="font-semibold text-gray-900">{module.title}</h3>
                        <p className="text-sm text-gray-500">
                          {module.lessons} lessons • {module.duration}
                        </p>
                      </div>
                      {expandedModule === moduleIndex ? 
                        <ChevronUp className="h-5 w-5 text-gray-400" /> : 
                        <ChevronDown className="h-5 w-5 text-gray-400" />
                      }
                    </button>
                    
                    {expandedModule === moduleIndex && (
                      <div className="border-t border-gray-200">
                        {module.lessons_detail.map((lesson, lessonIndex) => (
                          <div key={lessonIndex} className="flex items-center justify-between p-4 border-b border-gray-100 last:border-b-0">
                            <div className="flex items-center">
                              <Play className="h-4 w-4 text-gray-400 mr-3" />
                              <span className="text-gray-700">{lesson.title}</span>
                              {lesson.preview && (
                                <span className="ml-2 px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                                  Preview
                                </span>
                              )}
                            </div>
                            <span className="text-sm text-gray-500">{lesson.duration}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Requirements */}
            <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Requirements</h2>
              <ul className="space-y-3">
                {course.requirements.map((requirement, index) => (
                  <li key={index} className="flex items-start">
                    <div className="w-2 h-2 bg-gray-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700">{requirement}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Description */}
            <div className="bg-white rounded-xl shadow-lg p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Description</h2>
              <div className="prose prose-gray max-w-none">
                {course.description.split('\n\n').map((paragraph, index) => (
                  <p key={index} className="text-gray-700 leading-relaxed mb-4">
                    {paragraph}
                  </p>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              {/* Course Preview Card */}
              <div className="bg-white rounded-xl shadow-lg overflow-hidden mb-6">
                <div className="relative">
                  <img 
                    src={course.thumbnail}
                    alt={course.title}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center">
                    <button className="bg-white bg-opacity-90 hover:bg-opacity-100 rounded-full p-4 transition-all">
                      <Play className="h-8 w-8 text-gray-900" />
                    </button>
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="text-center mb-6">
                    <div className="flex items-center justify-center space-x-2 mb-2">
                      <span className="text-3xl font-bold text-gray-900">${course.price}</span>
                      <span className="text-lg text-gray-500 line-through">${course.originalPrice}</span>
                    </div>
                    <p className="text-sm text-green-600 font-semibold">40% off limited time</p>
                  </div>

                  <div className="space-y-3 mb-6">
                    <Link
                      to={`/learn/${course.id}/1`}
                      className="block w-full text-center px-4 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-lg hover:shadow-lg transition-all"
                    >
                      Enroll Now
                    </Link>
                    <button className="w-full px-4 py-3 border-2 border-gray-300 text-gray-700 font-semibold rounded-lg hover:border-gray-400 transition-colors">
                      Add to Cart
                    </button>
                  </div>

                  <div className="text-center text-sm text-gray-500 mb-6">
                    30-Day Money-Back Guarantee
                  </div>

                  <div className="space-y-4 border-t border-gray-200 pt-6">
                    <h3 className="font-semibold text-gray-900 mb-3">This course includes:</h3>
                    <div className="space-y-3 text-sm">
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 text-gray-400 mr-3" />
                        <span>12 hours on-demand video</span>
                      </div>
                      <div className="flex items-center">
                        <BookOpen className="h-4 w-4 text-gray-400 mr-3" />
                        <span>45 coding exercises</span>
                      </div>
                      <div className="flex items-center">
                        <Download className="h-4 w-4 text-gray-400 mr-3" />
                        <span>Downloadable resources</span>
                      </div>
                      <div className="flex items-center">
                        <Award className="h-4 w-4 text-gray-400 mr-3" />
                        <span>Certificate of completion</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CourseDetailPage;