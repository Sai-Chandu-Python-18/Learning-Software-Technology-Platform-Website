import React, { useState } from 'react';
import { 
  User, Mail, Calendar, MapPin, Award, BookOpen, Clock, 
  TrendingUp, Edit3, Camera, Star, Download, Share2,
  Github, Linkedin, Twitter, Globe
} from 'lucide-react';

const ProfilePage = () => {
  const [activeTab, setActiveTab] = useState('overview');

  const user = {
    name: "Alex Thompson",
    email: "alex.thompson@email.com",
    avatar: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg",
    title: "Full Stack Developer",
    location: "San Francisco, CA",
    joinDate: "January 2023",
    bio: "Passionate developer with 3+ years of experience in React, Node.js, and cloud technologies. Always learning and building amazing things.",
    social: {
      github: "alexthompson",
      linkedin: "alex-thompson-dev",
      twitter: "@alexdev",
      website: "alexthompson.dev"
    }
  };

  const stats = [
    { label: "Courses Completed", value: "12", icon: <BookOpen className="h-5 w-5" /> },
    { label: "Learning Hours", value: "248", icon: <Clock className="h-5 w-5" /> },
    { label: "Certificates Earned", value: "8", icon: <Award className="h-5 w-5" /> },
    { label: "Current Streak", value: "15 days", icon: <TrendingUp className="h-5 w-5" /> }
  ];

  const certificates = [
    {
      id: 1,
      title: "React Developer Certification",
      issuer: "TechLearn Academy",
      date: "March 2024",
      credentialId: "TL-RD-2024-001234",
      image: "https://images.pexels.com/photos/270348/pexels-photo-270348.jpeg"
    },
    {
      id: 2,
      title: "AWS Cloud Practitioner",
      issuer: "Amazon Web Services",
      date: "February 2024",
      credentialId: "AWS-CP-2024-567890",
      image: "https://images.pexels.com/photos/1181298/pexels-photo-1181298.jpeg"
    },
    {
      id: 3,
      title: "Node.js Backend Specialist",
      issuer: "TechLearn Academy",
      date: "January 2024",
      credentialId: "TL-NB-2024-987654",
      image: "https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg"
    }
  ];

  const completedCourses = [
    {
      id: 1,
      title: "React Mastery: Modern Frontend Development",
      instructor: "Sarah Johnson",
      completedDate: "March 15, 2024",
      rating: 5,
      thumbnail: "https://images.pexels.com/photos/270348/pexels-photo-270348.jpeg"
    },
    {
      id: 2,
      title: "AWS Cloud Practitioner Certification",
      instructor: "David Rodriguez",
      completedDate: "February 28, 2024",
      rating: 5,
      thumbnail: "https://images.pexels.com/photos/1181298/pexels-photo-1181298.jpeg"
    },
    {
      id: 3,
      title: "Node.js & Express: Complete Backend Guide",
      instructor: "Michael Chen",
      completedDate: "January 22, 2024",
      rating: 4,
      thumbnail: "https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg"
    }
  ];

  const skillProgress = [
    { skill: "React", level: 90, color: "bg-blue-500" },
    { skill: "Node.js", level: 85, color: "bg-green-500" },
    { skill: "TypeScript", level: 80, color: "bg-purple-500" },
    { skill: "AWS", level: 70, color: "bg-orange-500" },
    { skill: "Docker", level: 65, color: "bg-cyan-500" },
    { skill: "Python", level: 60, color: "bg-yellow-500" }
  ];

  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'certificates', label: 'Certificates' },
    { id: 'courses', label: 'Completed Courses' },
    { id: 'skills', label: 'Skills' }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Profile Header */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden mb-8">
          <div className="h-32 bg-gradient-to-r from-blue-600 via-purple-600 to-blue-800"></div>
          <div className="relative px-8 pb-8">
            <div className="flex flex-col sm:flex-row sm:items-end sm:space-x-6 -mt-16">
              <div className="relative">
                <img
                  src={user.avatar}
                  alt={user.name}
                  className="w-32 h-32 rounded-full border-4 border-white shadow-lg object-cover"
                />
                <button className="absolute bottom-2 right-2 bg-blue-600 text-white p-2 rounded-full hover:bg-blue-700 transition-colors">
                  <Camera className="h-4 w-4" />
                </button>
              </div>
              
              <div className="flex-1 mt-4 sm:mt-0">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <h1 className="text-3xl font-bold text-gray-900">{user.name}</h1>
                    <p className="text-lg text-gray-600">{user.title}</p>
                    <div className="flex items-center text-gray-500 mt-2 space-x-4">
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 mr-1" />
                        <span className="text-sm">{user.location}</span>
                      </div>
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1" />
                        <span className="text-sm">Joined {user.joinDate}</span>
                      </div>
                    </div>
                  </div>
                  
                  <button className="mt-4 sm:mt-0 flex items-center px-4 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-colors">
                    <Edit3 className="h-4 w-4 mr-2" />
                    Edit Profile
                  </button>
                </div>
                
                <p className="text-gray-700 mt-4 leading-relaxed">{user.bio}</p>
                
                {/* Social Links */}
                <div className="flex items-center space-x-4 mt-4">
                  <a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">
                    <Github className="h-5 w-5" />
                  </a>
                  <a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">
                    <Linkedin className="h-5 w-5" />
                  </a>
                  <a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">
                    <Twitter className="h-5 w-5" />
                  </a>
                  <a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">
                    <Globe className="h-5 w-5" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg p-6">
              <div className="flex items-center">
                <div className="p-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg mr-4">
                  {stat.icon}
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  <p className="text-sm text-gray-600">{stat.label}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-xl shadow-lg">
          <div className="border-b border-gray-200">
            <nav className="px-8 -mb-px flex space-x-8">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>

          <div className="p-8">
            {/* Overview Tab */}
            {activeTab === 'overview' && (
              <div className="space-y-8">
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-4">Learning Journey</h3>
                  <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-6">
                    <div className="grid md:grid-cols-3 gap-6">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-blue-600 mb-2">12</div>
                        <p className="text-gray-600">Courses Completed</p>
                      </div>
                      <div className="text-center">
                        <div className="text-3xl font-bold text-purple-600 mb-2">248h</div>
                        <p className="text-gray-600">Total Learning Time</p>
                      </div>
                      <div className="text-center">
                        <div className="text-3xl font-bold text-green-600 mb-2">8</div>
                        <p className="text-gray-600">Certificates Earned</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-4">Recent Activity</h3>
                  <div className="space-y-4">
                    <div className="flex items-center p-4 bg-gray-50 rounded-lg">
                      <Award className="h-8 w-8 text-yellow-500 mr-4" />
                      <div>
                        <p className="font-medium text-gray-900">Earned React Developer Certification</p>
                        <p className="text-sm text-gray-600">March 15, 2024</p>
                      </div>
                    </div>
                    <div className="flex items-center p-4 bg-gray-50 rounded-lg">
                      <BookOpen className="h-8 w-8 text-blue-500 mr-4" />
                      <div>
                        <p className="font-medium text-gray-900">Completed AWS Cloud Practitioner Course</p>
                        <p className="text-sm text-gray-600">February 28, 2024</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Certificates Tab */}
            {activeTab === 'certificates' && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-gray-900">My Certificates</h3>
                  <p className="text-gray-600">{certificates.length} certificates earned</p>
                </div>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {certificates.map((cert) => (
                    <div key={cert.id} className="border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-shadow">
                      <div className="text-center mb-4">
                        <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-3">
                          <Award className="h-8 w-8 text-white" />
                        </div>
                        <h4 className="font-bold text-gray-900 mb-1">{cert.title}</h4>
                        <p className="text-sm text-gray-600">{cert.issuer}</p>
                      </div>
                      <div className="space-y-2 mb-4">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-500">Issued:</span>
                          <span className="text-gray-900">{cert.date}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-500">ID:</span>
                          <span className="text-gray-900">{cert.credentialId}</span>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <button className="flex-1 flex items-center justify-center px-3 py-2 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 transition-colors">
                          <Download className="h-4 w-4 mr-1" />
                          Download
                        </button>
                        <button className="flex items-center justify-center px-3 py-2 border border-gray-300 text-gray-700 text-sm rounded-lg hover:bg-gray-50 transition-colors">
                          <Share2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Completed Courses Tab */}
            {activeTab === 'courses' && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-gray-900">Completed Courses</h3>
                  <p className="text-gray-600">{completedCourses.length} courses completed</p>
                </div>
                <div className="space-y-4">
                  {completedCourses.map((course) => (
                    <div key={course.id} className="flex items-center p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
                      <img
                        src={course.thumbnail}
                        alt={course.title}
                        className="w-16 h-16 rounded-lg object-cover mr-4"
                      />
                      <div className="flex-1">
                        <h4 className="font-semibold text-gray-900 mb-1">{course.title}</h4>
                        <p className="text-sm text-gray-600 mb-2">by {course.instructor}</p>
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`h-4 w-4 ${
                                  i < course.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
                                }`}
                              />
                            ))}
                          </div>
                          <span className="text-sm text-gray-500">Completed: {course.completedDate}</span>
                        </div>
                      </div>
                      <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors">
                        View Certificate
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Skills Tab */}
            {activeTab === 'skills' && (
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-6">Technical Skills</h3>
                <div className="space-y-6">
                  {skillProgress.map((skill, index) => (
                    <div key={index}>
                      <div className="flex justify-between mb-2">
                        <span className="font-medium text-gray-900">{skill.skill}</span>
                        <span className="text-sm text-gray-600">{skill.level}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <div
                          className={`${skill.color} h-3 rounded-full transition-all duration-1000`}
                          style={{ width: `${skill.level}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;